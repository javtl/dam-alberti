# Ejercicio 6: Convertir grados Celsius a Fahrenheit

def conversor(grados):
    celsius_fahrenheit = (grados * 9 / 5) + 32 
    fahrenheit_celsius = (grados - 32) * 5 / 9 = 0 

    return f"{celsius_fahrenheit} , {fahrenheit_celsius}"

grados = float(input("Ingrese los grados a convertir"))

print(conversor)