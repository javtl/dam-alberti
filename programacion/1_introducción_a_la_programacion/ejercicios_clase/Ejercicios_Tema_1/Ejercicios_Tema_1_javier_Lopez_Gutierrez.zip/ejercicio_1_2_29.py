import random

#Cálculo de un número aleatorio entre dos valores

a = int(input("Ingrese un número minimo: "))
b = int(input("Ingrese un número máximo: "))

numero = random.randint(a,b)