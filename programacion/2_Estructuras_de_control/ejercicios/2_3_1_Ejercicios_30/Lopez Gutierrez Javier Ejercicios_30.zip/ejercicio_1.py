# Ejercicio 1: Subprograma que salude, sin parámetros

def saludo():
    print("Hola")