# Reemplazar palabras enteras dentro de una cadena

cadena = input("Ingrese una cadena de caracteres: ")

cadena_python = cadena.replace("Hola", "Python")

print(cadena_python)