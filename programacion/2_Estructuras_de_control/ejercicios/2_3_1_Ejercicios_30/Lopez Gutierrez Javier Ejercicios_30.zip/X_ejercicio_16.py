# Ejercicio 16: Realiza un subalgoritmo que permita a un usuario intentar 3 veces acertar el PIN 
# de acceso a un dispositivo.