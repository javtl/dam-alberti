# Hay un método de cadenas llamado find, que es similar a count.
# Escribe el código necesario para invocar a este método find y contar el número de 
# veces que una letra aparece en “banana”.

palabra = banana
