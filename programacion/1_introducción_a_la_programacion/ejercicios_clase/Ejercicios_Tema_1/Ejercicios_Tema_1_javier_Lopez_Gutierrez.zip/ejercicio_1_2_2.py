'''
Escribe un programa para pedirle al usuario las horas de trabajo y el precio por hora y
calcule el importe total del servicio.
Horas de trabajo: 6
Coste por hora: 10
Importe total: 60
'''

horas = float(input("Ingrese el numero de horas trabajadas: "))
importe = float(input("Ingrese el numero de horas trabajadas: "))

importe_total = horas * importe
print(f"El importe por las horas trabajadas es: {importe_total}")
