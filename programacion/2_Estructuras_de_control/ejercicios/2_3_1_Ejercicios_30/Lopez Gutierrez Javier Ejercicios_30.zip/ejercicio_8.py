# Ejercicio 8: Mostrar línea decorativa con guiones

def linea_decorativa():
    print("-------------")