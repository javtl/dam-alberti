'''
Escribir un programa que muestre por pantalla el resultado de la siguiente operación
aritmética (3+2/2*5)**2
'''

resultado = (3+2/2*5)**2

print(f"El resultado de la operación (3+2/2*5)**2 es: {resultado}")