# Buscar la primera aparición de una letra

cadena = input("Ingrese una cadena: ")

buscar_a = cadena.find("a")

print(cadena)
print(buscar_a)