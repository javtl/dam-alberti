package com.example.nuevomineral;

import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;

public class MisticaPico extends PickaxeItem {
    public MisticaPico(Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
    }
}
