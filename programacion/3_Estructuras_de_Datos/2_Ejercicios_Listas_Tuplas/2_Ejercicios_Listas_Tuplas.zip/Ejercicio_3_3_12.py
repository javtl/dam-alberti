# Escribir un programa que almacene las matrices
# matriz 2x3
# A=
# 1, 2, 3
# 4, 5, 6
# matriz 3x2
# B=
# −1, 0
# 0, 1
# 1, 1
