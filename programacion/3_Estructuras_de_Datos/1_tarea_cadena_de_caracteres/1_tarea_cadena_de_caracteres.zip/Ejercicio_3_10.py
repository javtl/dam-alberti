# Elimina los espacios de una frase
frase = input("Ingrese una frase: ")

elimina_espacios = frase.strip()

print(elimina_espacios)
