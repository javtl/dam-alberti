'''
Escribe un programa que pida el nombre del usuario para luego darle la bienvenida.
Escribe tu nombre: Juan
Hola, Juan.
'''

nombre = input("Ingrese su nombre: ")
print(f"Hola, {nombre}")