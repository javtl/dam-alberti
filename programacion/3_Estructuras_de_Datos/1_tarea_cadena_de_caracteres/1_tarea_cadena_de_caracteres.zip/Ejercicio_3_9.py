# Mostrar la posición que ocupa cada letra dentro de la cadena
cadena = ("Ingrese una cadena: ")

for i in range (0, len(cadena)):
    print(f"{i} , {cadena[i]}")