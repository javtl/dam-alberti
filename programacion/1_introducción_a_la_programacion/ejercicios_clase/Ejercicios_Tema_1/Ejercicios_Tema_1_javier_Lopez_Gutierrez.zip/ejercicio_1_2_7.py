'''
Escribe un programa que solicite tres números al usuario y calcule e imprima por pantalla
su suma.
'''

n1 = float(input("Ingrese un primer número: "))
n2 = float(input("Ingrese un segundo número: "))
n3 = float(input("Ingrese un tercer número: "))

suma = n1+n2+n3

print(f"La suma de {n1} + {n2} + {n3} es: {suma}")