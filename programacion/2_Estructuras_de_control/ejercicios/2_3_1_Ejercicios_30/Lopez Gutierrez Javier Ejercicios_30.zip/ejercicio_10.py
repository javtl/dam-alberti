# Ejercicio 10: Evaluar si una edad permite votar

def puede_votar (edad):
    if edad >= 18 :
        return True
    else :
        return False

int = input("Ingrese su edad: ")

