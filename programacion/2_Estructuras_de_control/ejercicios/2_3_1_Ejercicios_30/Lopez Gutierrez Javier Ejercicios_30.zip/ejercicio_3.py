# Ejercicio 3: Multiplicar sin usar el símbolo * (dos números)

def multiplica(x,y):
    mult = x*y
    return mult

x = float(input("Ingrese un número: "))
y = float (input(f"Ingrese un número para multiplicar: "))

multiplica(x,y)

print(multiplica)