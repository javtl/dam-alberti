document.write("<p>Párrafo escrito desde JS</p>");
console.log("Esto va a la consola de JS");

