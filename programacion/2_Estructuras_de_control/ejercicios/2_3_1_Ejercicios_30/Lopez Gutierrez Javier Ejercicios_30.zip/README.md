# EJERCICIOS 3.0: Subprogramas 
### Básico: 
Ejercicio 1: Subprograma que salude, sin parámetros 
Ejercicio 2: Ahora Saludo personalizado 
Ejercicio 3: Multiplicar sin usar el símbolo * (dos números) 
Ejercicio 4: Indicar si un número es par 
Ejercicio 5: Mostrar menú con 3 opciones: 1. Nueva Tarea 2. Ver Tareas 3. Salir 
Ejercicio 6: Convertir grados Celsius a Fahrenheit 
Ejercicio 7: Contar vocales, en una palabra 
Ejercicio 8: Mostrar línea decorativa con guiones 
Ejercicio 9: Calcular el área de un rectángulo 
Ejercicio 10: Evaluar si una edad permite votar 
 
### Medio: 
Ejercicio 11: Realiza un subprograma que intercambie el valor de dos variables enteras. 
Ejercicio 12: Calcula la solución de una ecuación de segundo grado contemplando las 
diferentes condiciones de entrada que se puedan dar. 
 
### Avanzado: 
Ejercicio 13: Crea un subprogama que indique si un número es primo o no lo es. 
Ejercicio 14: Utilizando el ejercicio anterior, indica los divisores del número. 
Ejercicio 15: Crea un subprograma que reciba una nota decimal y devuelva si está suspenso, 
aprobado, notable o sobresaliente. 
Ejercicio 16: Realiza un subalgoritmo que permita a un usuario intentar 3 veces acertar el PIN 
de acceso a un dispositivo.