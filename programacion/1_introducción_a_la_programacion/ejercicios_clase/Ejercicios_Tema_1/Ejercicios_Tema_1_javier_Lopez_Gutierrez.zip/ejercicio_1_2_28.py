# Calcular el área de un triángulo a partir de tres lados
    # con los tres lados solo puedo calcular el perimetro necesitaria la base y la altura para calcular el área
l1 = float(input("Ingrese un lado: "))
l2 = float(input("Ingrese un lado: "))
l3 = float(input("Ingrese un lado: "))

#area = (b * h)/2    
perimetro = l1+l2+l3
print(f"El perimetro del triangulo es: {perimetro}")