'''
Escribir el programa del ejercicio 1.7 usando solamente dos variables diferentes.
'''
n1 = float(input("Ingrese un primer número: "))
n2 = float(input("Ingrese un segundo número: "))


suma = n1+n2

print(f"La suma de {n1} + {n2} es: {suma}")