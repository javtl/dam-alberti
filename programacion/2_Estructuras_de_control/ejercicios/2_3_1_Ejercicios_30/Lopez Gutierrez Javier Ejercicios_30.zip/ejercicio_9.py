# Ejercicio 9: Calcular el área de un rectángulo

def area_rectangulo(base, altura) :

    area = base*altura
    return area

base = float(input("Introduzca la base del rectangulo: "))
altura =  float(input("Introduzca la altura del rectangulo: "))

