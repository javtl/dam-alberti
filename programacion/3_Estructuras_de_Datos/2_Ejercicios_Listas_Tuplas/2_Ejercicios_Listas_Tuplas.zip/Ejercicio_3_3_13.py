# Realiza un programa que compruebe la letra del DNI y detecte si el
# usuario se ha equivocado con los números