# PROGRAMA DE PRUEBA PARA LA RESTA IMPLEMENTADA EN MENU CALCULADORA
from menuCalculadora import resta


a=100
b=201
resultado=resta(a,b)
print("La resta es: ", resultado)