# Ejercicio 11: Realiza un subprograma que intercambie el valor de dos variables enteras. 

def intercambiar_variables(a,b):
    a = b
    b = a

    return f"el valor de a intercambiado es: {a},el valor de a intercambiado es: {b}"

