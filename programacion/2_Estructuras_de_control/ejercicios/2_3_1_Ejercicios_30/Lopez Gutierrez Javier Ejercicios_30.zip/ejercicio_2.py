# Ejercicio 2: Ahora Saludo personalizado
def saludo_personalizado(nombre):
    print(f"Hola, {nombre}")

nombre = input("Ingrese su nombre: ")

print(saludo_personalizado)