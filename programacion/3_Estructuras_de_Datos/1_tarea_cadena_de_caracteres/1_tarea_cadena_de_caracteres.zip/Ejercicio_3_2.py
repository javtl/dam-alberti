# Dado que fruta es una variable de tipo cadena, ¿qué significa fruta[:]
fruta = ["Manzana", "Pera", "Sandia"]
fruta_copia = fruta[:]#crea una copia exacta

print(fruta)
print(fruta_copia)