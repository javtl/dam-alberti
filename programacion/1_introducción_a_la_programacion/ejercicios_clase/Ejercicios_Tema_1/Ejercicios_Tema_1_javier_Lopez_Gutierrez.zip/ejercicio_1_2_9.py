
'''
¿Es posible escribir el programa del ejercicio 1.7 sin usar variables? Inténtalo.
'''
print(
    float(input("Ingrese un primer número: ")) +
    float(input("Ingrese un segundo número: ")) +
    float(input("Ingrese un tercer número: "))
)